select*from walmartsales;
  -- so here is my very robust amount of timetaking data analysis over walmartsales dataset ...;
  
  -- Task 1: Identifying the Top Branch by Sales Growth Rate (Monthly)
SELECT 
    Branch,
    DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS Month,
    SUM(Total) AS MonthlySales
FROM walmartsales
GROUP BY Branch, Month
ORDER BY Branch, Month;



-- Task 2: Most Profitable Product Line for Each Branch
SELECT 
    Branch,
    `Product line`,
    SUM(`gross income`) AS TotalProfit
FROM walmartsales
GROUP BY Branch, `Product line`
ORDER BY Branch, TotalProfit DESC;

-- Task 3: Customer Segmentation Based on Spending
  
  --  so medium range is 21720 according to this i will set criteria
SELECT 
    `Customer ID`,
    ROUND(SUM(Total), 2) AS TotalSpent,
    CASE
        WHEN SUM(Total) > 21720 THEN 'High Spender'
        WHEN SUM(Total) between 20693  and 21720  THEN 'Medium Spender'
        ELSE 'Low Spender'
    END AS SpendingSegment
FROM walmartsales
GROUP BY `Customer ID`
ORDER BY TotalSpent DESC;


-- Task 4: Detecting Anomalies in Sales Transactions (using 1.5*IQR Method)
SELECT *
FROM (
    SELECT *,
        (Total - AVG(Total) OVER (PARTITION BY `Product line`)) / 
        STDDEV(Total) OVER (PARTITION BY `Product line`) AS Anomaly_Score
    FROM walmartsales
) AS sub
WHERE ABS(Anomaly_Score) > 2;  


-- Task 5: Most Popular Payment Method by City
SELECT 
    City,
    Payment,
    COUNT(*) AS UsageCount
FROM walmartsales
GROUP BY City, Payment
HAVING COUNT(*) = (
    SELECT MAX(c)
    FROM (
        SELECT COUNT(*) AS c
        FROM walmartsales AS inner_table
        WHERE inner_table.City = walmartsales.City
        GROUP BY inner_table.Payment
    ) AS sub
);

-- Task 6: Monthly Sales Distribution by Gender
SELECT 
    DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS Month,
    Gender,
    SUM(Total) AS TotalSales
FROM walmartsales
GROUP BY Month, Gender
ORDER BY Month;

-- Task 7: Best Product Line by Customer Type
SELECT 
    `Customer type`,
    `Product line`,
    SUM(Total) AS TotalSales
FROM walmartsales
GROUP BY `Customer type`, `Product line`
ORDER BY `Customer type`, TotalSales DESC;

-- Task 8: Identifying Repeat Customers (within 30 days)
WITH PurchaseDates AS (
    SELECT 
        `Customer ID`,
        `Invoice ID`,
        STR_TO_DATE(Date, '%d-%m-%Y') AS PurchaseDate
    FROM walmartsales
),
Repeated AS (
    SELECT 
        a.`Customer ID`,
        a.`Invoice ID` AS First_Invoice,
        a.PurchaseDate AS First_Purchase,
        b.`Invoice ID` AS Repeat_Invoice,
        b.PurchaseDate AS Repeat_Purchase,
        DATEDIFF(b.PurchaseDate, a.PurchaseDate) AS DaysBetween
    FROM PurchaseDates a
    JOIN PurchaseDates b 
        ON a.`Customer ID` = b.`Customer ID`
       AND b.PurchaseDate > a.PurchaseDate
)
SELECT *
FROM Repeated
WHERE DaysBetween <= 30
ORDER BY `Customer ID`, DaysBetween;


-- Task 9: Top 5 Customers by Sales Volume
SELECT 
    `Customer ID`,
    ROUND(SUM(Total), 2) AS TotalSpent
FROM walmartsales
GROUP BY `Customer ID`
ORDER BY TotalSpent DESC
LIMIT 5;

-- Task 10: Sales Trends by Day of the Week
SELECT 
    DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y')) AS Weekday,
    SUM(Total) AS TotalSales
FROM walmartsales
GROUP BY Weekday
ORDER BY FIELD(Weekday, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
